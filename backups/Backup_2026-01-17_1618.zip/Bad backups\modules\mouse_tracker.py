import threading
import time
import math

try:
    from pynput.mouse import Controller, Listener as MouseListener
    from pynput import keyboard
    _mouse = Controller()
    HAS_MOUSE = True
except ImportError:
    _mouse = None
    HAS_MOUSE = False
    print("⚠️ pynput not found. Mouse/Key tracking disabled.")

try:
    import os
    os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
    import pygame
    HAS_PYGAME = True
    # We might need to init pygame here if not already done, 
    # but usually it's better to do it in the Start method to avoid conflicts
except ImportError:
    HAS_PYGAME = False
    print("⚠️ pygame not found. Joystick tracking disabled.")

class InputController:
    def __init__(self, callback_func):
        """
        :param callback_func: Function to call with (x, y) coordinates
        """
        self.callback = callback_func
        self.running = False
        self.mode = "absolute" # 'absolute', 'relative', 'axis', 'keys'
        self.thread = None
        self.mouse_listener = None
        self.key_listener = None
        
        # State
        self.cursor_x = 0.5 # Normalized 0.0 - 1.0
        self.cursor_y = 0.5
        
        # Keys State (Pressed or Not)
        self.keys_state = {'up': False, 'down': False, 'left': False, 'right': False}
        self.key_map = {} # {'Key.up': 'up', 'w': 'up', ...}
        
        # Config
        self.joystick = None
        self.joysticks_map = {} # InstanceID -> JoyObj
        self.joy_map = {} # Direction -> Bind
        self.axis_idx_x = 0
        self.axis_idx_y = 1
        self.sensitivity = 0.015
        self.key_speed = 0.010 
        self.mouse_sens = 0.002 # For Relative Mode
    
    def get_cursor_pos(self):
        return self.cursor_x, self.cursor_y

    def start_tracking(self, mode="absolute", config=None):
        if self.running: return

        self.mode = mode
        self.running = True
        
        # 1. Setup Input Sources based on Mode
        if self.mode == "axis" and HAS_PYGAME:
            self.sensitivity = config.get('sensitivity', 0.015)
            self._setup_joystick(config)
        elif self.mode == "relative":
            self.mouse_sens = config.get('sensitivity', 0.002)
            self._start_mouse_listener()
        elif self.mode == "keys":
            self.key_speed = config.get('sensitivity', 0.010)
            self._start_key_listener(config)
            # Keys mode also supports Joystick Buttons now
            if HAS_PYGAME:
                self.joy_map = config.get('joy_map', {})
                self._setup_joystick(config) # Init generic (allocates all joysticks)

        self.thread = threading.Thread(target=self._tracking_loop, daemon=True)
        self.thread.start()
        print(f"🟢 TRACKER: Started in {mode.upper()} mode with config: {config}")

    def stop_tracking(self):
        self.running = False
        if self.thread:
            self.thread.join(timeout=1.0)
        
        # Cleanup Listeners
        if self.mouse_listener: 
            self.mouse_listener.stop()
            self.mouse_listener = None
        if self.key_listener:
            self.key_listener.stop()
            self.key_listener = None
            
        print("🔴 TRACKER: Stopped")

    def _setup_joystick(self, config):
        try:
            if not pygame.get_init(): pygame.init()
            if not pygame.joystick.get_init(): pygame.joystick.init()
            
            # Init ALL joysticks for lookup map
            self.joysticks_map = {}
            cnt = pygame.joystick.get_count()
            for i in range(cnt):
                try:
                    j = pygame.joystick.Joystick(i)
                    j.init()
                    self.joysticks_map[j.get_instance_id()] = j
                except: pass
                
            if cnt > 0:
                # Primary Axis Joystick (Legacy support for 'axis' mode)
                joy_id = config.get('joy_id', 0) if config else 0
                if joy_id < cnt:
                    self.joystick = pygame.joystick.Joystick(joy_id)
                    self.joystick.init()
                    self.axis_idx_x = config.get('axis_x', 0)
                    self.axis_idx_y = config.get('axis_y', 1)
                    print(f"🎮 TRACKER: Primary Axis Joy: {self.joystick.get_name()}")
        except Exception as e:
            print(f"❌ TRACKER PYGAME ERROR: {e}")

    def _start_mouse_listener(self):
        if not HAS_MOUSE: return
        def on_move(x, y):
            # We don't use absolute pos here, we need delta.
            # But pynput only gives abs pos. We must calc delta ourselves?
            # Actually, pynput.mouse.Listener gives absolute.
            # A better way for relative is just reading 'mouse.position' each frame
            # and resetting it to center? No, that steals the mouse.
            # Best way: Check delta from last frame in the loop.
            pass 
        # For Relative, we'll handle deltas in the main loop or use a trick.
        # Actually, pynput doesn't give raw deltas easily on Windows without hooking low level.
        # Simple Approach: Use current mouse pos, compare to last, apply delta to Virtual, then (optionally) re-center mouse?
        # User requested "Mouse Relative".
        # Let's just track position changes in the loop.
        pass

    def _start_key_listener(self, config):
        # Config: {'up': 'Key.up', 'down': 's', ...}
        # self.key_map = config if config else {}
        # Simple: Hardcoded arrows + WASD for now, or passed config
        self.key_map = config.get('key_map', {}) if config else {}
        
        def on_press(key):
            k = str(key).replace("'", "")
            if k in self.key_map: self.keys_state[self.key_map[k]] = True
        def on_release(key):
            k = str(key).replace("'", "")
            if k in self.key_map: self.keys_state[self.key_map[k]] = False
            
        self.key_listener = keyboard.Listener(on_press=on_press, on_release=on_release)
        self.key_listener.start()

    def _tracking_loop(self):
        last_mouse_pos = _mouse.position if (HAS_MOUSE and _mouse) else (0,0)

        while self.running:
            dx, dy = 0, 0
            
            # --- MODE 1: ABSOLUTE ---
            if self.mode == "absolute":
                if HAS_MOUSE and _mouse:
                    pos = _mouse.position
                    # Send Raw Pixels (Client handles Window Offset)
                    self.callback(pos[0], pos[1], normalized=False, mode="absolute")
            
            # --- MODE 2: RELATIVE ---
            elif self.mode == "relative":
                if HAS_MOUSE and _mouse:
                    curr_pos = _mouse.position
                    # Delta
                    mx = curr_pos[0] - last_mouse_pos[0]
                    my = curr_pos[1] - last_mouse_pos[1]
                    last_mouse_pos = curr_pos
                    
                    if mx != 0 or my != 0:
                        dx = mx * self.mouse_sens
                        dy = my * self.mouse_sens
                        
            # --- MODE 3: AXIS ---
            elif self.mode == "axis":
                if HAS_PYGAME and self.joystick:
                    pygame.event.pump()
                    raw_x = self.joystick.get_axis(self.axis_idx_x)
                    raw_y = self.joystick.get_axis(self.axis_idx_y)
                    if abs(raw_x) > 0.1: dx = raw_x * self.sensitivity
                    if abs(raw_y) > 0.1: dy = raw_y * self.sensitivity

            # --- MODE 4: KEYS ---
            elif self.mode == "keys":
                # Digital Movement
                # 1. Keyboard
                if self.keys_state.get('up'): dy -= self.key_speed
                if self.keys_state.get('down'): dy += self.key_speed
                if self.keys_state.get('left'): dx -= self.key_speed
                if self.keys_state.get('right'): dx += self.key_speed
                
                # 2. Joystick Buttons (Hat/Digital)
                if HAS_PYGAME:
                    pygame.event.pump() # Ensure states are updated
                    # Iterate helpers
                    for direction, bind in self.joy_map.items():
                        # Bind: [DevName, BtnIdx, ...]
                        if not bind or len(bind) < 2: continue
                        
                        target_dev = bind[0]
                        target_btn = int(bind[1])
                        
                        # Find matching joystick(s) - naive search every frame? 
                        # Better to specificy Joy object in setup, but DevID changes.
                        # We'll search self.joysticks dict
                        is_pressed = False
                        for j in self.joysticks_map.values():
                            if target_dev in j.get_name():
                                try:
                                    if j.get_button(target_btn): 
                                        is_pressed = True; break
                                except: pass
                        
                        if is_pressed:
                            if direction == 'up': dy -= self.key_speed
                            elif direction == 'down': dy += self.key_speed
                            elif direction == 'left': dx -= self.key_speed
                            elif direction == 'right': dx += self.key_speed

            # --- APPLY DELTAS (Relative, Axis, Keys) ---
            if self.mode != "absolute" and (dx != 0 or dy != 0):
                self.cursor_x += dx
                self.cursor_y += dy
                
                # Clamp
                self.cursor_x = max(0.0, min(1.0, self.cursor_x))
                self.cursor_y = max(0.0, min(1.0, self.cursor_y))
                
                self.callback(self.cursor_x, self.cursor_y, normalized=True, mode=self.mode)

            time.sleep(0.016) # ~60Hz