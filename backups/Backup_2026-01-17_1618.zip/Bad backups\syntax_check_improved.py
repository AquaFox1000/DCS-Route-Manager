
import re

def check_brackets(file_path):
    print(f"Checking {file_path}...")
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Find <script> tags that don't have a 'src' attribute
    # We use a primitive regex for this.
    scripts = []
    
    # Iterate over all matches including start pos to calculate file lines if needed
    # But simple list is fine for now.
    
    matches = re.finditer(r'<script\b[^>]*>(.*?)</script>', content, re.DOTALL)
    
    for i, match in enumerate(matches):
        tag_content = match.group(1)
        tag_start = match.start()
        
        # skip if src= is in the opening tag (regex above matches content, but we need to check the tag itself)
        # Actually, let's just inspect the Opening Tag.
        # It's hard to get the opening tag from the group(1) match alone.
        
        # Better: split file or primitive parse.
        # Let's just assume the big block we care about is the one with "var socket ="
        if "var socket =" in tag_content or "const socket =" in tag_content or "window.socket =" in tag_content:
            print(f"Analyzing Main Script Block (Index {i})...")
            check_script_content(tag_content)

def check_script_content(script_text):
    stack = []
    lines = script_text.split('\n')
    
    for line_idx, line in enumerate(lines):
        # Strip strings and comments for bracket checking (rough approximation)
        # remove string literals "..." and '...'
        # This is fragile but helps avoid counting brackets in strings.
        
        clean_line = line
        clean_line = re.sub(r'(")(?:\\.|[^\\])*?\1', '', clean_line) # double quotes
        clean_line = re.sub(r"(')(?:\\.|[^\\])*?\1", '', clean_line) # single quotes
        clean_line = re.sub(r'`(?:\\.|[^`])*?`', '', clean_line)     # backticks
        clean_line = re.sub(r'//.*', '', clean_line)      # single line comment
        
        # Check brackets
        for char in clean_line:
            if char in '({[':
                stack.append((char, line_idx + 1, line.strip()))
            elif char in ')}]':
                if not stack:
                    print(f"❌ Error: Unexpected '{char}' at Line {line_idx + 1}")
                    print(f"   Line Content: {line.strip()}")
                    return
                last, last_line, last_content = stack.pop()
                if (last == '(' and char != ')') or \
                   (last == '{' and char != '}') or \
                   (last == '[' and char != ']'):
                    print(f"❌ Error: Mismatched '{char}' at Line {line_idx + 1}")
                    print(f"   Line Content: {line.strip()}")
                    print(f"   Expected closing for '{last}' from Line {last_line}: {last_content}")
                    return
    
    if stack:
        last, last_line, last_content = stack[0]
        print(f"❌ Error: Unclosed '{last}' starting at Line {last_line}")
        print(f"   Line Content: {last_content}")
        return

    print("✅ Syntax Structure OK")

check_brackets('d:/AI Projects/DCS_Route_Manager/Templates/map.html')
